
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Home, Search, Library, ListMusic, Settings, Crown, 
  History as HistoryIcon, Sliders, Play, Pause, SkipForward, 
  SkipBack, Volume2, X, Music, CheckCircle2, Sparkles, 
  Loader2, ArrowRight, Disc, Timer, Palette, Shuffle, Repeat, Repeat1, Star
} from 'lucide-react';
import { 
  AppScreen, Song, ExcaliburTheme, PremiumPlan, 
  Playlist, PlayHistory, Language 
} from './types.ts';
import { THEMES, STORAGE_KEYS } from './constants.ts';
import { PremiumManager } from './services/premiumService.ts';
import { AIService } from './services/aiService.ts';
import { translations } from './locales/translations.ts';
import { OfflineStorage } from './services/storageService.ts';
import { CryptoManager } from './services/cryptoService.ts';

// --- COMPONENTS ---
import LibraryView from './components/Library.tsx';
import SearchView from './components/Search.tsx';
import PlaylistsView from './components/Playlists.tsx';
import SettingsView from './components/Settings.tsx';
import PremiumView from './components/Premium.tsx';
import HistoryView from './components/History.tsx';
import ThemeDesigner from './components/ThemeDesigner.tsx';
import Visualizer from './components/Visualizer.tsx';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>(AppScreen.HOME);
  const [currentTheme, setCurrentTheme] = useState<ExcaliburTheme>(THEMES[0]);
  const [customThemes, setCustomThemes] = useState<ExcaliburTheme[]>([]);
  const [language, setLanguage] = useState<Language>('en'); 
  const [activeSong, setActiveSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(1);
  const [library, setLibrary] = useState<Song[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [history, setHistory] = useState<PlayHistory[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [dlHistory, setDlHistory] = useState<number[]>([]);
  const [notification, setNotification] = useState<{msg: string, type: 'success' | 'error'} | null>(null);
  const [isPremiumActive, setIsPremiumActive] = useState(false);
  
  // Player Modes
  const [isShuffle, setIsShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<'off' | 'all' | 'one'>('off');

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const t = useMemo(() => translations[language], [language]);

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 3000);
  };

  useEffect(() => {
    const init = async () => {
      await PremiumManager.init();
      setIsPremiumActive(PremiumManager.isPremium());
      await OfflineStorage.init();
      
      const [savedLib, savedPl, savedHis, savedThemes, savedSet, savedDls] = await Promise.all([
        CryptoManager.loadSecure(STORAGE_KEYS.LIBRARY),
        CryptoManager.loadSecure(STORAGE_KEYS.PLAYLISTS),
        CryptoManager.loadSecure(STORAGE_KEYS.HISTORY),
        CryptoManager.loadSecure("excalibur_custom_themes"),
        CryptoManager.loadSecure(STORAGE_KEYS.SETTINGS),
        CryptoManager.loadSecure("excalibur_dl_history")
      ]);

      const safeParse = (data: string | null, fallback: any) => {
          if (!data) return fallback;
          try {
              const trimmed = data.trim();
              if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
                return JSON.parse(trimmed);
              }
              return fallback;
          } catch (e) {
              console.error("Erro ao processar dados seguros corrompidos:", e);
              return fallback;
          }
      };

      setLibrary(safeParse(savedLib, []));
      setPlaylists(safeParse(savedPl, []));
      setHistory(safeParse(savedHis, []));
      setCustomThemes(safeParse(savedThemes, []));
      setDlHistory(safeParse(savedDls, []));

      const settings = safeParse(savedSet, null);
      if (settings) {
        if (settings.language) setLanguage(settings.language);
        if (settings.themeId !== undefined) {
           const allThemes = [...THEMES, ...customThemes];
           const theme = allThemes.find(th => th.id === settings.themeId);
           if (theme) setCurrentTheme(theme);
        }
      }
      setIsLoading(false);
    };
    init();
  }, []);

  const saveLibrarySecurely = async (updated: Song[]) => {
    setLibrary(updated);
    await CryptoManager.saveSecure(STORAGE_KEYS.LIBRARY, JSON.stringify(updated));
  };

  const saveDlHistorySecurely = async (updated: number[]) => {
    setDlHistory(updated);
    await CryptoManager.saveSecure("excalibur_dl_history", JSON.stringify(updated));
  };

  const savePlaylistsSecurely = async (updated: Playlist[]) => {
    setPlaylists(updated);
    await CryptoManager.saveSecure(STORAGE_KEYS.PLAYLISTS, JSON.stringify(updated));
  };

  const saveSettingsSecurely = async (lang: Language, theme: ExcaliburTheme) => {
    const settings = { language: lang, themeId: theme.id };
    await CryptoManager.saveSecure(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  };

  const playSong = async (song: Song) => {
    let sourceUrl = await OfflineStorage.getAudio(song.id);
    
    if (!sourceUrl) {
        try {
            const resp = await fetch(song.url, { mode: 'cors' });
            if (!resp.ok) throw new Error("Fetch failed");
            const blob = await resp.blob();
            await OfflineStorage.saveAudio(song.id, blob);
            sourceUrl = await OfflineStorage.getAudio(song.id);
        } catch (e) {
            showToast("Streaming failed. Link expired.", "error");
            return;
        }
    }

    if (!sourceUrl) return;
    setActiveSong(song);
    setIsPlaying(true);
    
    const newEntry: PlayHistory = { id: Math.random().toString(36).substr(2, 9), songId: song.id, playedAt: Date.now() };
    const updatedHistory = [newEntry, ...history.slice(0, 49)];
    setHistory(updatedHistory);
    await CryptoManager.saveSecure(STORAGE_KEYS.HISTORY, JSON.stringify(updatedHistory));

    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = sourceUrl;
      audioRef.current.load();
      audioRef.current.play().catch(() => {});
    }
  };

  const handleNext = () => {
    if (!activeSong || library.length === 0) return;
    if (repeatMode === 'one') {
        if (audioRef.current) audioRef.current.currentTime = 0;
        audioRef.current?.play();
        return;
    }
    const currentIdx = library.findIndex(s => s.id === activeSong.id);
    let nextIdx;
    if (isShuffle) {
        nextIdx = Math.floor(Math.random() * library.length);
    } else {
        nextIdx = (currentIdx + 1) % library.length;
    }
    if (library[nextIdx]) playSong(library[nextIdx]);
  };

  const handlePrev = () => {
    if (!activeSong || library.length === 0) return;
    const currentIdx = library.findIndex(s => s.id === activeSong.id);
    const prevIdx = (currentIdx - 1 + library.length) % library.length;
    if (library[prevIdx]) playSong(library[prevIdx]);
  };

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) { audioRef.current.pause(); setIsPlaying(false); }
    else { audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {}); }
  };

  const handleAddToLibrary = async (song: Song) => {
      const updated = [song, ...library];
      await saveLibrarySecurely(updated);
      const updatedDls = [Date.now(), ...dlHistory];
      await saveDlHistorySecurely(updatedDls);
      showToast(t.library.added, "success");
  };

  const handlePremiumActivation = async (plan: PremiumPlan) => {
      await PremiumManager.activatePremium(plan, 'ORDER_' + Date.now());
      setIsPremiumActive(true);
      showToast(t.premium.checkout.confirmed, "success");
      setCurrentScreen(AppScreen.HOME);
  };

  if (isLoading) return <div className="h-screen w-screen bg-[#050505] flex items-center justify-center font-black tracking-[10px] animate-pulse text-white">EXCALIBUR</div>;

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden relative select-none transition-all duration-700" style={{ background: `linear-gradient(180deg, ${currentTheme.gradient[0]} 0%, ${currentTheme.gradient[1]} 100%)` }}>
      <audio 
        ref={audioRef} 
        onTimeUpdate={() => setProgress((audioRef.current?.currentTime || 0) / (audioRef.current?.duration || 1) * 100)} 
        onEnded={handleNext}
      />

      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full blur-[120px] opacity-40 pointer-events-none transition-all duration-1000" style={{ background: currentTheme.primary }} />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full blur-[120px] opacity-20 pointer-events-none transition-all duration-1000" style={{ background: currentTheme.primary }} />
      
      {notification && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] animate-in slide-in-from-top duration-300">
           <div className={`px-4 py-2 rounded-xl shadow-xl flex items-center gap-3 border ${notification.type === 'success' ? 'bg-green-500 text-white border-green-400' : 'bg-red-500 text-white border-red-400'}`}>
              <CheckCircle2 size={16} />
              <span className="font-bold text-xs">{notification.msg}</span>
           </div>
        </div>
      )}

      {/* MOBILE PREMIUM BUTTON */}
      {!isPremiumActive && currentScreen !== AppScreen.PREMIUM && (
        <button 
          onClick={() => setCurrentScreen(AppScreen.PREMIUM)}
          className="md:hidden fixed top-6 right-6 z-[90] w-12 h-12 bg-amber-500 text-black rounded-2xl flex items-center justify-center shadow-2xl animate-bounce hover:animate-none active:scale-95 transition-all"
        >
          <Crown size={24} />
        </button>
      )}

      <div className="flex-1 flex overflow-hidden z-10 relative">
        {/* SIDEBAR (Desktop) */}
        <nav className="hidden md:flex w-64 border-r border-white/5 flex-col bg-black/40 backdrop-blur-3xl">
          <div className="p-8 flex items-center gap-3">
             <div className="w-8 h-8 rounded-xl bg-white flex items-center justify-center text-black shadow-lg"><Music size={18} /></div>
             <h1 className="text-xl font-black tracking-tighter text-white uppercase">Excalibur</h1>
          </div>
          <div className="flex-1 px-4 space-y-1">
            <NavItem active={currentScreen === AppScreen.HOME} onClick={() => setCurrentScreen(AppScreen.HOME)} icon={<Home size={18} />} label={t.nav.home} />
            <NavItem active={currentScreen === AppScreen.SEARCH} onClick={() => setCurrentScreen(AppScreen.SEARCH)} icon={<Search size={18} />} label={t.nav.search} />
            <NavItem active={currentScreen === AppScreen.LIBRARY} onClick={() => setCurrentScreen(AppScreen.LIBRARY)} icon={<Library size={18} />} label={t.nav.library} />
            <NavItem active={currentScreen === AppScreen.PLAYLISTS} onClick={() => setCurrentScreen(AppScreen.PLAYLISTS)} icon={<ListMusic size={18} />} label={t.nav.playlists} />
            <NavItem active={currentScreen === AppScreen.HISTORY} onClick={() => setCurrentScreen(AppScreen.HISTORY)} icon={<HistoryIcon size={18} />} label={t.nav.history} />
          </div>
          <div className="p-6">
            <button onClick={() => setCurrentScreen(AppScreen.PREMIUM)} className={`w-full py-4 font-black rounded-2xl flex items-center justify-center gap-2 transition-transform text-[10px] uppercase tracking-widest shadow-lg ${isPremiumActive ? 'bg-white/10 text-white' : 'bg-amber-500 text-black'}`}>
                <Crown size={16} /> {isPremiumActive ? "Prestige Status" : t.nav.premium}
            </button>
            <button onClick={() => setCurrentScreen(AppScreen.SETTINGS)} className={`w-full mt-4 flex items-center gap-3 px-4 py-3 rounded-2xl transition-all ${currentScreen === AppScreen.SETTINGS ? 'bg-white/10 text-white' : 'text-white/40 hover:text-white'}`}>
                <Settings size={18} /> <span className="text-[10px] font-bold uppercase tracking-widest">{t.nav.settings}</span>
            </button>
          </div>
        </nav>

        {/* MOBILE BOTTOM NAV */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 h-20 bg-black/80 backdrop-blur-3xl border-t border-white/10 flex items-center justify-around px-4 z-[90] pb-safe">
            <MobileNavItem active={currentScreen === AppScreen.HOME} onClick={() => setCurrentScreen(AppScreen.HOME)} icon={<Home size={22} />} />
            <MobileNavItem active={currentScreen === AppScreen.SEARCH} onClick={() => setCurrentScreen(AppScreen.SEARCH)} icon={<Search size={22} />} />
            <MobileNavItem active={currentScreen === AppScreen.LIBRARY} onClick={() => setCurrentScreen(AppScreen.LIBRARY)} icon={<Library size={22} />} />
            <MobileNavItem active={currentScreen === AppScreen.HISTORY} onClick={() => setCurrentScreen(AppScreen.HISTORY)} icon={<HistoryIcon size={22} />} />
            <MobileNavItem active={currentScreen === AppScreen.SETTINGS} onClick={() => setCurrentScreen(AppScreen.SETTINGS)} icon={<Settings size={22} />} />
        </nav>

        <main className="flex-1 overflow-y-auto no-scrollbar relative">
            <div className="max-w-5xl mx-auto p-6 md:p-12 pb-64">
                {currentScreen === AppScreen.HOME && <HomeView onPlay={playSong} library={library} history={history} t={t} onNavigate={setCurrentScreen} isPremium={isPremiumActive} />}
                {currentScreen === AppScreen.LIBRARY && <LibraryView library={library} onUpdateLibrary={saveLibrarySecurely} onPlay={playSong} t={t} />}
                {currentScreen === AppScreen.SEARCH && <SearchView onPlay={playSong} library={library} onAddToLibrary={handleAddToLibrary} dlHistory={dlHistory} t={t} />}
                {currentScreen === AppScreen.SETTINGS && <SettingsView currentTheme={currentTheme} customThemes={customThemes} onUpdateTheme={(th) => { setCurrentTheme(th); saveSettingsSecurely(language, th); }} onOpenDesigner={() => setCurrentScreen(AppScreen.DESIGNER)} currentLang={language} onUpdateLang={(l) => { setLanguage(l); saveSettingsSecurely(l, currentTheme); }} onExport={() => {}} onImport={() => {}} dlHistory={dlHistory} t={t} />}
                {currentScreen === AppScreen.DESIGNER && <ThemeDesigner initialTheme={currentTheme} onBack={() => setCurrentScreen(AppScreen.SETTINGS)} onSave={async (theme) => { const updated = [theme, ...customThemes]; setCustomThemes(updated); await CryptoManager.saveSecure("excalibur_custom_themes", JSON.stringify(updated)); setCurrentTheme(theme); await saveSettingsSecurely(language, theme); setCurrentScreen(AppScreen.SETTINGS); }} t={t} />}
                {currentScreen === AppScreen.PREMIUM && <PremiumView onActivate={handlePremiumActivation} t={t} />}
                {currentScreen === AppScreen.PLAYLISTS && <PlaylistsView playlists={playlists} onUpdatePlaylists={savePlaylistsSecurely} songs={library} onPlay={playSong} t={t} />}
                {currentScreen === AppScreen.HISTORY && <HistoryView history={history} songs={library} onPlay={playSong} t={t} />}
            </div>
        </main>

        {/* PLAYER BAR */}
        {activeSong && (
          <div className="fixed bottom-24 md:bottom-8 left-4 right-4 md:left-72 md:right-8 z-[80] animate-in slide-in-from-bottom duration-500">
             <div className="bg-black/80 backdrop-blur-3xl border border-white/20 rounded-[2.5rem] p-4 flex flex-col md:flex-row items-center gap-4 md:gap-8 shadow-[0_20px_50px_rgba(0,0,0,0.5)] relative overflow-hidden group">
                <div className="absolute inset-0 opacity-10 pointer-events-none">
                    <Visualizer isPlaying={isPlaying} audioRef={audioRef} color={currentTheme.primary} />
                </div>
                
                {/* Info */}
                <div className="flex items-center gap-4 relative z-10 shrink-0 min-w-0 w-full md:w-64">
                    <img src={activeSong.thumbnail} className="w-12 h-12 rounded-2xl object-cover shadow-lg shrink-0 border border-white/10" />
                    <div className="min-w-0">
                        <h4 className="font-bold text-sm truncate text-white">{activeSong.title}</h4>
                        <p className="text-[9px] text-white/50 font-bold uppercase truncate tracking-wider">{activeSong.artist}</p>
                    </div>
                </div>

                {/* Controls */}
                <div className="flex-1 flex flex-col gap-2 relative z-10 w-full">
                    <div className="flex items-center justify-center gap-6">
                        <button onClick={() => setIsShuffle(!isShuffle)} className={`transition-all ${isShuffle ? 'text-amber-500 scale-110' : 'text-white/20 hover:text-white/40'}`}>
                            <Shuffle size={16} />
                        </button>
                        <button onClick={handlePrev} className="text-white/60 hover:text-white transition-all hover:scale-110">
                            <SkipBack size={20} fill="currentColor" />
                        </button>
                        <button onClick={togglePlay} className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center shadow-lg hover:scale-110 active:scale-95 transition-all">
                            {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-0.5" />}
                        </button>
                        <button onClick={handleNext} className="text-white/60 hover:text-white transition-all hover:scale-110">
                            <SkipForward size={20} fill="currentColor" />
                        </button>
                        <button onClick={() => setRepeatMode(repeatMode === 'off' ? 'all' : repeatMode === 'all' ? 'one' : 'off')} className={`transition-all ${repeatMode !== 'off' ? 'text-amber-500 scale-110' : 'text-white/20 hover:text-white/40'}`}>
                            {repeatMode === 'one' ? <Repeat1 size={16} /> : <Repeat size={16} />}
                        </button>
                    </div>
                    
                    <div className="flex items-center gap-3 px-2">
                        <span className="text-[8px] font-mono text-white/40 w-8 text-right shrink-0">
                           {audioRef.current ? formatTime(audioRef.current.currentTime) : '0:00'}
                        </span>
                        <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden cursor-pointer group/progress" onClick={(e) => {
                            if (!audioRef.current || !audioRef.current.duration) return;
                            const rect = e.currentTarget.getBoundingClientRect();
                            const x = e.clientX - rect.left;
                            audioRef.current.currentTime = (x / rect.width) * audioRef.current.duration;
                        }}>
                            <div className="h-full transition-all duration-300" style={{ width: `${progress}%`, background: currentTheme.primary }} />
                        </div>
                        <span className="text-[8px] font-mono text-white/40 w-8 shrink-0">
                           {audioRef.current ? formatTime(audioRef.current.duration) : '0:00'}
                        </span>
                    </div>
                </div>

                {/* Volume (Desktop Only) */}
                <div className="hidden lg:flex items-center gap-4 relative z-10 px-4">
                    <Volume2 size={16} className="text-white/40" />
                    <input type="range" min="0" max="1" step="0.01" value={volume} onChange={(e) => {
                         const v = parseFloat(e.target.value);
                         setVolume(v);
                         if (audioRef.current) audioRef.current.volume = v;
                    }} className="w-20 h-1 bg-white/10 rounded-full appearance-none accent-white cursor-pointer" />
                </div>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

const formatTime = (time: number) => {
    if (isNaN(time)) return '0:00';
    const min = Math.floor(time / 60);
    const sec = Math.floor(time % 60);
    return `${min}:${sec.toString().padStart(2, '0')}`;
};

const NavItem: React.FC<{ active: boolean, onClick: () => void, icon: React.ReactNode, label: string }> = ({ active, onClick, icon, label }) => (
  <button onClick={onClick} className={`w-full flex items-center gap-4 px-6 py-3 rounded-xl transition-all ${active ? 'bg-white text-black shadow-lg scale-[1.02]' : 'text-white/40 hover:text-white hover:bg-white/5'}`}>
    {icon}
    <span className="font-bold text-[10px] uppercase tracking-widest">{label}</span>
  </button>
);

const MobileNavItem: React.FC<{ active: boolean, onClick: () => void, icon: React.ReactNode }> = ({ active, onClick, icon }) => (
    <button onClick={onClick} className={`p-4 rounded-xl transition-all ${active ? 'bg-white text-black scale-110 shadow-lg' : 'text-white/40 hover:text-white/60'}`}>
        {icon}
    </button>
);

const HomeView: React.FC<{ onPlay: (s: Song) => void, library: Song[], history: PlayHistory[], t: any, onNavigate: (s: AppScreen) => void, isPremium: boolean }> = ({ onPlay, library, history, t, onNavigate, isPremium }) => {
    const recentSongs = useMemo(() => {
        const uniqueIds = Array.from(new Set(history.map(h => h.songId))).slice(0, 4);
        return uniqueIds.map(id => library.find(s => s.id === id)).filter(Boolean) as Song[];
    }, [history, library]);

    return (
        <div className="space-y-16 animate-in fade-in slide-in-from-bottom duration-700">
            <header className="py-8 md:py-12 flex flex-col items-center text-center space-y-6">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 border border-white/20 rounded-full text-[9px] font-black tracking-widest text-white uppercase">
                    <Sparkles size={12} className="text-amber-500" /> {t.home.fidelity}
                </div>
                <h2 className="text-4xl md:text-5xl font-black font-display tracking-tight leading-tight text-white px-4">
                    {t.home.welcome} <br />
                    <span className="text-white/20">{t.home.welcomeSuffix}</span>
                </h2>
                <div className="flex flex-col sm:flex-row gap-4 px-6 w-full sm:w-auto">
                    <button onClick={() => onNavigate(AppScreen.SEARCH)} className="px-8 py-4 bg-white text-black font-black rounded-2xl flex items-center justify-center gap-3 hover:scale-105 transition-all text-[10px] uppercase tracking-widest shadow-lg">
                        <Search size={18} /> {t.home.start}
                    </button>
                    {!isPremium && (
                       <button onClick={() => onNavigate(AppScreen.PREMIUM)} className="px-8 py-4 bg-amber-500 text-black font-black rounded-2xl flex items-center justify-center gap-3 hover:scale-105 transition-all text-[10px] uppercase tracking-widest shadow-lg">
                          <Crown size={18} /> {t.premium.activate}
                       </button>
                    )}
                </div>
            </header>

            {!isPremium && (
                <div className="md:hidden mx-4 p-8 bg-gradient-to-br from-amber-500 to-orange-600 rounded-[2.5rem] shadow-2xl relative overflow-hidden group" onClick={() => onNavigate(AppScreen.PREMIUM)}>
                    <div className="absolute top-0 right-0 p-6 opacity-20 group-hover:scale-125 transition-transform"><Crown size={80} /></div>
                    <div className="relative z-10 space-y-4">
                        <div className="flex items-center gap-2 text-black/40 font-black text-[8px] uppercase tracking-widest">
                            <Star size={10} fill="currentColor" /> {t.home.limitedOffer}
                        </div>
                        <h3 className="text-2xl font-black text-black leading-tight">{t.home.unlockElite}</h3>
                        <p className="text-black/60 text-[10px] font-bold max-w-[200px]">{t.home.unlockDesc}</p>
                        <button className="px-6 py-3 bg-black text-white rounded-xl font-black text-[9px] uppercase tracking-widest flex items-center gap-2">
                            {t.common.upgradeNow} <ArrowRight size={12} />
                        </button>
                    </div>
                </div>
            )}

            {recentSongs.length > 0 && (
                <section className="space-y-6 px-4">
                    <h3 className="text-lg font-black uppercase tracking-widest px-2 text-white">{t.home.recent}</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                        {recentSongs.map(song => (
                            <div key={song.id} onClick={() => onPlay(song)} className="group cursor-pointer space-y-3">
                                <div className="aspect-square rounded-2xl overflow-hidden relative shadow-lg bg-black/40 border border-white/10">
                                    <img src={song.thumbnail} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all">
                                        <Play fill="currentColor" size={24} className="text-white" />
                                    </div>
                                </div>
                                <div className="px-1">
                                    <h4 className="font-bold text-xs truncate text-white">{song.title}</h4>
                                    <p className="text-[9px] text-white/40 font-bold uppercase truncate">{song.artist}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>
            )}

            <section className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-20 px-4">
                <div className="p-8 bg-white/5 border border-white/10 rounded-3xl space-y-4 hover:bg-white/10 transition-all cursor-pointer group" onClick={() => onNavigate(AppScreen.LIBRARY)}>
                    <Disc size={28} className="text-blue-400 group-hover:scale-110 transition-transform" />
                    <h3 className="text-xl font-black uppercase text-white">{t.nav.library}</h3>
                    <p className="text-white/40 text-xs">{t.home.libDesc}</p>
                </div>
                <div className="p-8 bg-white/5 border border-white/10 rounded-3xl space-y-4 hover:bg-white/10 transition-all cursor-pointer group" onClick={() => onNavigate(AppScreen.SEARCH)}>
                    <Sparkles size={28} className="text-purple-400 group-hover:scale-110 transition-transform" />
                    <h3 className="text-xl font-black uppercase text-white">{t.home.exploreCloud}</h3>
                    <p className="text-white/40 text-xs">{t.home.exploreDesc}</p>
                </div>
            </section>
        </div>
    );
};

export default App;


import { ExcaliburTheme, PremiumPlan } from './types';

export const THEMES: ExcaliburTheme[] = [
  {
    id: 0,
    name: "Apple Arctic",
    primary: "#007AFF",
    secondary: "#101116",
    background: "#101116",
    accent: "#007AFF",
    gradient: ["#101116", "#1C1C1E"],
    isPremium: false
  },
  {
    id: 1,
    name: "Spotify",
    primary: "#1DB954",
    secondary: "#121212",
    background: "#121212",
    accent: "#1DB954",
    gradient: ["#181818", "#121212"],
    isPremium: false
  },
  {
    id: 2,
    name: "Cyberpunk",
    primary: "#FF003C",
    secondary: "#0D0D0D",
    background: "#0D0D0D",
    accent: "#FF003C",
    gradient: ["#151515", "#0D0D0D"],
    isPremium: true
  },
  {
    id: 3,
    name: "Oceanic",
    primary: "#00D2FF",
    secondary: "#000428",
    background: "#000428",
    accent: "#00D2FF",
    gradient: ["#000835", "#004e92"],
    isPremium: true
  },
  {
    id: 4,
    name: "Sunset",
    primary: "#FF512F",
    secondary: "#140008",
    background: "#140008",
    accent: "#FF512F",
    gradient: ["#1F000B", "#2c0012"],
    isPremium: true
  }
];

export const PRICES = {
  [PremiumPlan.MONTHLY]: "4.99",
  [PremiumPlan.YEARLY]: "29.99",
  [PremiumPlan.LIFETIME]: "59.99"
};

export const STORAGE_KEYS = {
  PREMIUM_STATUS: "excalibur_premium_status",
  PLAYLISTS: "excalibur_playlists",
  HISTORY: "excalibur_history",
  SETTINGS: "excalibur_settings",
  LIBRARY: "excalibur_library"
};

export const API_KEYS = {
  RAPID_API: "8ed62ca7c5msh2f6b793b33c887dp1a5499jsnf136d5071315",
  HOSTS: {
    PRIMARY: "youtube-mp3-audio-video-downloader.p.rapidapi.com",
    DOWNLOADER: "yt-search-and-download-mp3.p.rapidapi.com",
    YOUTUBE_DL: "youtube-info-download-api.p.rapidapi.com",
    SPOTIFY_DL: "spotify-downloader9.p.rapidapi.com"
  }
};


import { PremiumStatus, PremiumPlan, PremiumFeature } from '../types';
import { CryptoManager } from './cryptoService';
import { STORAGE_KEYS } from '../constants';

let currentStatus: PremiumStatus = {
  isPremium: false,
  expiresAt: 0,
  plan: PremiumPlan.FREE,
  paypalOrderId: '',
  purchasedAt: 0
};

export const PremiumManager = {
  init: async () => {
    const saved = await CryptoManager.loadSecure(STORAGE_KEYS.PREMIUM_STATUS);
    if (saved) {
      try {
        // Proteção contra strings que não são JSON (como o erro de token 'W')
        if (saved.startsWith('{')) {
          currentStatus = JSON.parse(saved);
        } else {
          console.warn("Premium Status corrompido detectado, ignorando.");
        }
      } catch (e) {
        console.error("Failed to parse premium status", e);
      }
    }
  },

  getStatus: () => currentStatus,

  isPremium: () => {
    if (!currentStatus.isPremium) return false;
    if (currentStatus.plan === PremiumPlan.LIFETIME) return true;
    return currentStatus.expiresAt > Date.now();
  },

  getDownloadLimit: (): number => {
    if (!PremiumManager.isPremium()) return 15; // 15 downloads por 2h
    if (currentStatus.plan === PremiumPlan.MONTHLY) return 100;
    return 999999; // Unlimited para Pro/Legendary
  },

  checkFeature: (feature: PremiumFeature): boolean => {
    return PremiumManager.isPremium();
  },

  activatePremium: async (plan: PremiumPlan, orderId: string) => {
    let expiresAt = 0;
    const now = Date.now();
    
    if (plan === PremiumPlan.MONTHLY) expiresAt = now + 30 * 24 * 60 * 60 * 1000;
    else if (plan === PremiumPlan.YEARLY) expiresAt = now + 365 * 24 * 60 * 60 * 1000;
    else if (plan === PremiumPlan.LIFETIME) expiresAt = Number.MAX_SAFE_INTEGER;

    currentStatus = {
      isPremium: true,
      expiresAt,
      plan,
      paypalOrderId: orderId,
      purchasedAt: now
    };

    await CryptoManager.saveSecure(STORAGE_KEYS.PREMIUM_STATUS, JSON.stringify(currentStatus));
    // Não usamos reload imediato aqui para permitir que a UI mostre sucesso, o App.tsx cuidará da atualização de estado
    return currentStatus;
  }
};

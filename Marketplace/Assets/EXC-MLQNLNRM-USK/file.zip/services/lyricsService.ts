
import { LyricLine } from '../types';

export const LyricsManager = {
  fetchLyrics: async (title: string, artist: string): Promise<LyricLine[]> => {
    try {
      const response = await fetch(`https://lrclib.net/api/get?artist_name=${encodeURIComponent(artist)}&track_name=${encodeURIComponent(title)}`);
      const data = await response.json();
      
      const lrcString = data.syncedLyrics || data.plainLyrics;
      if (!lrcString) return [];
      
      return LyricsManager.parseLRC(lrcString);
    } catch (e) {
      console.error("Lyrics fetch error:", e);
      return [];
    }
  },

  parseLRC: (lrc: string): LyricLine[] => {
    const lines = lrc.split('\n');
    const result: LyricLine[] = [];
    const regex = /\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)/;

    lines.forEach(line => {
      const match = regex.exec(line);
      if (match) {
        const min = parseInt(match[1]);
        const sec = parseInt(match[2]);
        const msStr = match[3];
        const ms = parseInt(msStr.padEnd(3, '0').substring(0, 3));
        const text = match[4].trim();
        
        const timeMs = (min * 60000) + (sec * 1000) + ms;
        result.push({ timeMs, text });
      } else if (line.trim()) {
          // If it's just plain text without timestamps
          result.push({ timeMs: -1, text: line.trim() });
      }
    });

    return result.sort((a, b) => a.timeMs - b.timeMs);
  }
};


import { GoogleGenAI } from "@google/genai";

export const AIService = {
  // Added language parameter to fix "Expected 2 arguments, but got 3" error in App.tsx line 218
  getSongContext: async (title: string, artist: string, language: string = 'en') => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Determine prompt language based on the application's current language
      const langName = language === 'pt' ? 'Portuguese' : language === 'it' ? 'Italian' : 'English';

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze the song "${title}" by "${artist}". 
        Provide a short text (maximum 3 paragraphs) in ${langName} containing:
        1. The predominant emotional vibe.
        2. A technical or historical curiosity about the track or album.
        3. What this song says about the personality of someone who listens to it.
        Be poetic, sophisticated and use a professional music critic tone.`,
      });

      return response.text || (language === 'pt' ? "Não foi possível conectar com a essência desta música no momento." : "Could not connect with the essence of this song at the moment.");
    } catch (error) {
      console.error("Erro na AI Discovery:", error);
      return language === 'pt' ? "O Excalibur AI está meditando. Tente novamente em breve." : "Excalibur AI is meditating. Try again soon.";
    }
  }
};

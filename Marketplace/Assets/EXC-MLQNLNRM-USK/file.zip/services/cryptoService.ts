
/**
 * Gerenciador de Criptografia do Excalibur
 * Protege a integridade dos dados de backup e status premium.
 */
export const CryptoManager = {
  // Chave de derivacao interna (Simulada para o protótipo)
  SECRET_SALT: "excalibur_secure_v2_2025",

  encrypt: async (plainText: string): Promise<string> => {
    // Simulando criptografia de bloco
    const data = btoa(unescape(encodeURIComponent(plainText)));
    const signature = await CryptoManager.hashSHA256(data + CryptoManager.SECRET_SALT);
    // O formato final é: [DADOS_BASE64].[ASSINATURA_HASH]
    return `${data}.${signature}`;
  },

  decrypt: async (payload: string): Promise<string | null> => {
    const parts = payload.split('.');
    if (parts.length !== 2) return null;

    const [data, providedSignature] = parts;
    const expectedSignature = await CryptoManager.hashSHA256(data + CryptoManager.SECRET_SALT);

    // Verificação de integridade: Se o hash não bater, o arquivo foi adulterado
    if (providedSignature !== expectedSignature) {
      console.error("ALERTA DE SEGURANÇA: Arquivo de backup corrompido ou adulterado!");
      return null;
    }

    try {
      return decodeURIComponent(escape(atob(data)));
    } catch (e) {
      return null;
    }
  },

  hashSHA256: async (data: string): Promise<string> => {
    const encoder = new TextEncoder();
    const buffer = encoder.encode(data);
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  },

  saveSecure: async (key: string, value: string) => {
    const encrypted = await CryptoManager.encrypt(value);
    localStorage.setItem(key, encrypted);
  },

  loadSecure: async (key: string): Promise<string | null> => {
    const encrypted = localStorage.getItem(key);
    if (!encrypted) return null;
    return await CryptoManager.decrypt(encrypted);
  }
};

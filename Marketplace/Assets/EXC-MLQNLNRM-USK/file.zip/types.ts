
export type Language = 'pt' | 'en' | 'it';

export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  isFavorite: boolean;
  dateAdded: number;
  url: string;
  thumbnail?: string;
  isOffline?: boolean; // Novo: Indica se o arquivo está no IndexedDB
}

export interface SearchResult {
  id: string;
  title: string;
  author: string;
  duration: string;
  thumbnail: string;
}

export interface ExcaliburTheme {
  id: number | string;
  name: string;
  primary: string;
  secondary: string;
  background: string;
  accent: string;
  gradient: string[];
  isPremium: boolean;
}

export interface Playlist {
  id: string;
  name: string;
  songIds: string[];
  createdAt: number;
  coverUrl?: string;
}

export interface LyricLine {
  timeMs: number;
  text: string;
}

export interface PremiumStatus {
  isPremium: boolean;
  expiresAt: number;
  plan: PremiumPlan;
  paypalOrderId: string;
  purchasedAt: number;
}

export enum PremiumPlan {
  FREE = 'FREE',
  MONTHLY = 'MONTHLY',
  YEARLY = 'YEARLY',
  LIFETIME = 'LIFETIME'
}

export enum PremiumFeature {
  UNLIMITED_DOWNLOADS = 'UNLIMITED_DOWNLOADS',
  ALL_THEMES = 'ALL_THEMES',
  FULL_EQUALIZER = 'FULL_EQUALIZER',
  UNLIMITED_PLAYLISTS = 'UNLIMITED_PLAYLISTS',
  LYRICS = 'LYRICS',
  WAVEFORM = 'WAVEFORM',
  PLAYBACK_SPEED = 'PLAYBACK_SPEED',
  SLEEP_TIMER = 'SLEEP_TIMER',
  CROSSFADE = 'CROSSFADE',
  NO_ADS = 'NO_ADS',
  HISTORY = 'HISTORY'
}

export enum AppScreen {
  HOME = 'HOME',
  SEARCH = 'SEARCH',
  LIBRARY = 'LIBRARY',
  PLAYLISTS = 'PLAYLISTS',
  SETTINGS = 'SETTINGS',
  PREMIUM = 'PREMIUM',
  EQUALIZER = 'EQUALIZER',
  HISTORY = 'HISTORY',
  DESIGNER = 'DESIGNER'
}

export interface PlayHistory {
  id: string;
  songId: string;
  playedAt: number;
}

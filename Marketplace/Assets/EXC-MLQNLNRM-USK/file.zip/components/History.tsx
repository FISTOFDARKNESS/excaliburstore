
import React from 'react';
import { PlayHistory, Song } from '../types.ts';
import { Clock, Play, Trash2 } from 'lucide-react';
import { STORAGE_KEYS } from '../constants.ts';

interface HistoryViewProps {
  history: PlayHistory[];
  songs: Song[];
  onPlay: (song: Song) => void;
  t: any;
}

const HistoryView: React.FC<HistoryViewProps> = ({ history, songs, onPlay, t }) => {
  const historyWithSongs = history.map(h => ({
    ...h,
    song: songs.find(s => s.id === h.songId)
  })).filter(h => h.song);

  const clearHistory = () => {
    if (confirm(t.history.confirmClear)) {
        localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify([]));
        window.location.reload();
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom duration-500">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-extrabold font-display">{t.history.title}</h2>
          <p className="text-white/40">{t.history.subtitle}</p>
        </div>
        {history.length > 0 && (
          <button onClick={clearHistory} className="flex items-center gap-2 px-6 py-3 bg-red-500/10 text-red-500 font-bold rounded-2xl hover:bg-red-500 hover:text-white transition-all">
            <Trash2 size={20} /> {t.history.clear}
          </button>
        )}
      </header>

      <div className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden backdrop-blur-md">
        {historyWithSongs.length > 0 ? (
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-white/5 text-white/30 text-[10px] font-black uppercase tracking-widest">
                <th className="px-6 py-4 w-12">#</th>
                <th className="px-6 py-4">{t.library.table.track}</th>
                <th className="px-6 py-4">{t.history.playedAt}</th>
                <th className="px-6 py-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {historyWithSongs.map((entry, idx) => (
                <tr key={entry.id} className="group hover:bg-white/5 cursor-pointer border-b border-white/5 last:border-0" onClick={() => entry.song && onPlay(entry.song)}>
                  <td className="px-6 py-4 text-white/30">{idx + 1}</td>
                  <td className="px-6 py-4">
                     <div className="flex items-center gap-4">
                        <img src={entry.song?.thumbnail} className="w-10 h-10 rounded-lg" />
                        <div><p className="font-bold">{entry.song?.title}</p><p className="text-xs text-white/40">{entry.song?.artist}</p></div>
                     </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-white/40">
                     <div className="flex items-center gap-2"><Clock size={12} /> {new Date(entry.playedAt).toLocaleString()}</div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-2 bg-white text-black rounded-full opacity-0 group-hover:opacity-100 transition-opacity"><Play fill="currentColor" size={14} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="py-32 flex flex-col items-center justify-center text-white/10">
             <Clock size={64} className="mb-4" />
             <p className="font-bold text-xl">{t.history.none}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default HistoryView;


import React, { useState, useEffect, useRef } from 'react';
import { Song, LyricLine, PremiumFeature } from '../types';
import { LyricsManager } from '../services/lyricsService';
import { PremiumManager } from '../services/premiumService';
import { Crown, MessageSquareOff } from 'lucide-react';

interface LyricsViewProps {
  song: Song;
  currentTimeMs: number;
  isPremium: boolean;
}

const LyricsView: React.FC<LyricsViewProps> = ({ song, currentTimeMs, isPremium }) => {
  const [lyrics, setLyrics] = useState<LyricLine[]>([]);
  const [loading, setLoading] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);
  const activeLineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isPremium) {
      setLoading(false);
      return;
    }

    const loadLyrics = async () => {
      setLoading(true);
      const fetched = await LyricsManager.fetchLyrics(song.title, song.artist);
      setLyrics(fetched);
      setLoading(false);
    };
    loadLyrics();
  }, [song, isPremium]);

  useEffect(() => {
    if (activeLineRef.current && containerRef.current) {
      activeLineRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [currentTimeMs]);

  if (!isPremium) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center p-8 bg-black/40 backdrop-blur-3xl rounded-3xl border border-white/5">
         <div className="w-16 h-16 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-500 mb-6">
            <Crown size={32} />
         </div>
         <h3 className="text-2xl font-bold mb-3">Premium Exigido</h3>
         <p className="text-white/40 max-w-xs leading-relaxed">
            As letras sincronizadas estão disponíveis apenas para membros Excalibur Premium.
         </p>
         <button className="mt-8 px-8 py-3 bg-amber-500 text-black font-bold rounded-xl hover:scale-105 transition-transform">
            Ver Planos Premium
         </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-white/10 border-t-white rounded-full animate-spin"></div>
      </div>
    );
  }

  if (lyrics.length === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-white/20 gap-4">
        <MessageSquareOff size={48} />
        <p className="font-semibold text-xl">Nenhuma letra encontrada.</p>
      </div>
    );
  }

  return (
    <div 
        ref={containerRef}
        className="h-full overflow-y-auto px-4 py-32 space-y-12 no-scrollbar mask-gradient"
    >
      {lyrics.map((line, idx) => {
        const isActive = currentTimeMs >= line.timeMs && (idx === lyrics.length - 1 || currentTimeMs < lyrics[idx + 1].timeMs);
        const isPast = currentTimeMs > line.timeMs;
        
        return (
          <div 
            key={idx}
            ref={isActive ? activeLineRef : null}
            className={`transition-all duration-700 font-display text-4xl md:text-5xl font-extrabold cursor-default leading-tight ${
              isActive 
              ? 'text-white scale-105 opacity-100' 
              : isPast ? 'text-white/20 opacity-80' : 'text-white/40 opacity-40 hover:opacity-100'
            }`}
          >
            {line.text}
          </div>
        );
      })}
      
      <style>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .mask-gradient {
            -webkit-mask-image: linear-gradient(transparent, black 20%, black 80%, transparent);
            mask-image: linear-gradient(transparent, black 20%, black 80%, transparent);
        }
      `}</style>
    </div>
  );
};

export default LyricsView;

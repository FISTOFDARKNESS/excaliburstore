
import React, { useEffect, useRef } from 'react';

interface VisualizerProps {
  isPlaying: boolean;
  audioRef: React.RefObject<HTMLAudioElement | null>;
  color: string;
}

// Singleton storage to prevent "HTMLMediaElement already connected" errors
const audioGlobals = new Map<HTMLAudioElement, {
  context: AudioContext;
  source: MediaElementAudioSourceNode;
  analyser: AnalyserNode;
}>();

const Visualizer: React.FC<VisualizerProps> = ({ isPlaying, audioRef, color }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(null);

  useEffect(() => {
    const audioEl = audioRef.current;
    if (!audioEl || !canvasRef.current) return;

    let globals = audioGlobals.get(audioEl);

    if (!globals) {
      try {
        const context = new (window.AudioContext || (window as any).webkitAudioContext)();
        const source = context.createMediaElementSource(audioEl);
        const analyser = context.createAnalyser();
        
        source.connect(analyser);
        analyser.connect(context.destination);
        
        analyser.fftSize = 256;
        globals = { context, source, analyser };
        audioGlobals.set(audioEl, globals);
      } catch (err) {
        console.error("Audio Visualizer initialization failed:", err);
        return;
      }
    }

    const { context, analyser } = globals;

    // Resume context if suspended (browser policy)
    if (isPlaying && context.state === 'suspended') {
      context.resume();
    }

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d')!;
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      animationRef.current = requestAnimationFrame(draw);
      analyser.getByteFrequencyData(dataArray);

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const barWidth = (canvas.width / bufferLength) * 2.5;
      let barHeight;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        barHeight = dataArray[i] / 2;
        
        // Dynamic gradient based on the passed color
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.6;
        ctx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
        
        ctx.fillStyle = 'white';
        ctx.globalAlpha = 0.2;
        ctx.fillRect(x, canvas.height - barHeight - 2, barWidth, 1);
        
        x += barWidth + 1;
      }
    };

    if (isPlaying) {
      draw();
    } else {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [isPlaying, audioRef, color]);

  return <canvas ref={canvasRef} className="w-full h-24 opacity-50" width={600} height={100} />;
};

export default Visualizer;


import React, { useRef, useState, useEffect } from 'react';
import { Song } from '../types.ts';
import { 
  Plus, Trash2, Music, Download, Youtube, 
  Link as LinkIcon, Loader2, Sparkles, Music2, 
  Search, HardDriveDownload, CheckCircle2, AlertCircle, FileAudio,
  Play, Timer, Disc, Check
} from 'lucide-react';
import { STORAGE_KEYS, API_KEYS } from '../constants.ts';
import { OfflineStorage } from '../services/storageService.ts';
import { PremiumManager } from '../services/premiumService.ts';
import { CryptoManager } from '../services/cryptoService.ts';

interface LibraryViewProps {
  library: Song[];
  onUpdateLibrary: (songs: Song[]) => void;
  onPlay: (song: Song) => void;
  t: any;
}

const LibraryView: React.FC<LibraryViewProps> = ({ library, onUpdateLibrary, onPlay, t }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importUrl, setImportUrl] = useState("");
  const [isImporting, setIsImporting] = useState(false);
  const [showImportPanel, setShowImportPanel] = useState(false);
  const [activeSource, setActiveSource] = useState<'youtube' | 'spotify'>('youtube');
  const [dlHistory, setDlHistory] = useState<number[]>([]);

  useEffect(() => {
    const loadDls = async () => {
        const saved = await CryptoManager.loadSecure("excalibur_dl_history");
        if (saved) setDlHistory(JSON.parse(saved));
    };
    loadDls();
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newSongs: Song[] = (Array.from(files) as File[])
      .filter(f => f.type.startsWith('audio/'))
      .map(file => ({
        id: `local_${Math.random().toString(36).substr(2, 9)}`,
        title: file.name.replace(/\.[^/.]+$/, ""),
        artist: "Local Storage",
        album: "Local Device",
        duration: 0,
        isFavorite: false,
        isOffline: true,
        dateAdded: Date.now(),
        url: URL.createObjectURL(file),
        thumbnail: `https://picsum.photos/seed/${Math.random()}/400`
      }));
    onUpdateLibrary([...newSongs, ...library]);
  };

  const handleImportAndPlay = async () => {
    if (!importUrl.trim()) return;
    setIsImporting(true);

    try {
      const apiUrl = `https://${API_KEYS.HOSTS.DOWNLOADER}/mp3?url=${encodeURIComponent(importUrl)}`;
      const response = await fetch(apiUrl, {
        headers: {
          'x-rapidapi-key': API_KEYS.RAPID_API,
          'x-rapidapi-host': API_KEYS.HOSTS.DOWNLOADER
        }
      });

      const data = await response.json();
      if (data && data.success && data.download) {
        const newSong: Song = {
          id: `cloud_${Date.now()}`,
          title: data.title || "Track Importada",
          artist: activeSource === 'youtube' ? "YouTube Cloud" : "Spotify Cloud",
          album: "Cloud Library",
          duration: 0,
          isFavorite: false,
          dateAdded: Date.now(),
          url: data.download,
          thumbnail: `https://i.ytimg.com/vi/${importUrl.split('v=')[1] || 'default'}/hqdefault.jpg`
        };
        
        setShowImportPanel(false);
        setImportUrl("");
        onPlay(newSong);
      } else {
        throw new Error("Sourcing failed");
      }
    } catch (e) {
      alert(t.settings.importError);
    } finally {
      setIsImporting(false);
    }
  };

  const recentDls = dlHistory.filter(time => time > Date.now() - (2 * 60 * 60 * 1000));
  const remainingDl = PremiumManager.getDownloadLimit() - recentDls.length;

  return (
    <div className="space-y-10 pb-40 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl md:text-6xl font-black font-display tracking-tight uppercase">{t.library.title}</h2>
          <div className="flex items-center gap-4 mt-2">
             <p className="text-white/40 text-[10px] font-black uppercase tracking-[3px]">{library.length} {t.library.stats}</p>
             <div className="px-3 py-1 bg-white/5 rounded-full flex items-center gap-2 text-[8px] font-black uppercase tracking-widest text-amber-500 border border-amber-500/20">
                <Timer size={10} /> {remainingDl < 0 ? 0 : remainingDl} {t.settings.creditsLeft}
             </div>
          </div>
        </div>
        <div className="flex gap-3">
          <button onClick={() => setShowImportPanel(!showImportPanel)} className={`flex items-center gap-2 px-6 py-4 rounded-2xl transition-all border font-black text-[10px] uppercase tracking-widest ${showImportPanel ? 'bg-white text-black border-white shadow-2xl' : 'bg-white/5 border-white/10 text-white/60 hover:text-white'}`}>
            <Download size={16} /> {t.library.cloudImport}
          </button>
          <button onClick={() => fileInputRef.current?.click()} className="px-8 py-4 bg-white text-black font-black rounded-2xl hover:scale-105 transition-all text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl">
            <Plus size={16} /> {t.library.add}
          </button>
        </div>
        <input type="file" ref={fileInputRef} className="hidden" multiple accept="audio/*" onChange={handleFileUpload} />
      </header>

      {showImportPanel && (
        <div className="bg-black/60 backdrop-blur-3xl border border-white/10 p-8 md:p-14 rounded-[4rem] animate-in zoom-in-95 duration-500 shadow-2xl space-y-10 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none"><Sparkles size={200} /></div>
          
          <div className="flex items-center gap-6">
            <button 
                onClick={() => setActiveSource('youtube')}
                className={`flex-1 flex items-center justify-center gap-4 py-6 rounded-[2rem] border-2 transition-all font-black text-xs uppercase tracking-[3px] ${activeSource === 'youtube' ? 'bg-red-600 border-red-500 shadow-[0_0_50px_rgba(220,38,38,0.3)]' : 'bg-white/5 border-white/5 text-white/40'}`}
            >
                <Youtube size={24} /> YouTube
            </button>
            <button 
                onClick={() => setActiveSource('spotify')}
                className={`flex-1 flex items-center justify-center gap-4 py-6 rounded-[2rem] border-2 transition-all font-black text-xs uppercase tracking-[3px] ${activeSource === 'spotify' ? 'bg-[#1DB954] border-[#1ed760] shadow-[0_0_50px_rgba(29,185,84,0.3)]' : 'bg-white/5 border-white/5 text-white/40'}`}
            >
                <Music2 size={24} /> Spotify
            </button>
          </div>

          <div className="flex flex-col md:flex-row gap-6">
              <div className="flex-1 relative">
                <LinkIcon className={`absolute left-8 top-1/2 -translate-y-1/2 transition-colors ${activeSource === 'youtube' ? 'text-red-500' : 'text-green-500'}`} size={24} />
                <input 
                    type="text" 
                    value={importUrl}
                    onChange={e => setImportUrl(e.target.value)}
                    placeholder={t.library.pasteLink}
                    className="w-full bg-white/5 border border-white/10 rounded-[2.5rem] py-8 pl-20 pr-8 text-lg font-bold focus:outline-none focus:bg-white/10 transition-all text-white"
                />
              </div>
              <button 
                onClick={handleImportAndPlay}
                disabled={isImporting || !importUrl}
                className={`px-12 py-8 rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 transition-all ${isImporting ? 'bg-white/10 text-white/20' : 'bg-white text-black hover:scale-105 active:scale-95 shadow-2xl'}`}
              >
                {isImporting ? <Loader2 size={24} className="animate-spin" /> : <Play size={24} fill="currentColor" />}
                {isImporting ? t.library.sourcing : t.library.playNow}
              </button>
          </div>
          <p className="text-[10px] font-black text-white/20 uppercase tracking-[4px] text-center">{t.library.noteFidelity}</p>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4">
        {library.map((song) => (
          <div key={song.id} onClick={() => onPlay(song)} className="group flex items-center gap-6 p-4 bg-white/5 border border-white/5 rounded-[2.5rem] hover:bg-white/10 transition-all cursor-pointer">
            <div className="relative w-20 h-20 rounded-3xl overflow-hidden shadow-2xl bg-black/40 shrink-0">
              <img src={song.thumbnail} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all">
                 <Play size={24} className="text-white" fill="currentColor" />
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-black text-lg truncate leading-tight">{song.title}</h4>
              <p className="text-[10px] text-white/30 font-black uppercase tracking-widest truncate mt-1">{song.artist}</p>
              {song.isOffline && (
                <div className="mt-2 flex items-center gap-2 text-green-500/60 text-[8px] font-black uppercase tracking-widest">
                    <Check size={10} /> {t.player.offline}
                </div>
              )}
            </div>
            <div className="flex items-center gap-4 pr-6">
              <button onClick={(e) => { e.stopPropagation(); onUpdateLibrary(library.filter(s => s.id !== song.id)); }} className="p-4 text-white/10 hover:text-red-500 hover:bg-red-500/5 rounded-2xl transition-all">
                <Trash2 size={20} />
              </button>
            </div>
          </div>
        ))}
      </div>
      
      {library.length === 0 && (
          <div className="py-40 flex flex-col items-center justify-center text-white/5 space-y-6">
              <Disc size={120} className="animate-spin-slow" />
              <p className="font-black uppercase tracking-[5px] text-sm">{t.library.emptyDesc}</p>
          </div>
      )}
    </div>
  );
};

export default LibraryView;

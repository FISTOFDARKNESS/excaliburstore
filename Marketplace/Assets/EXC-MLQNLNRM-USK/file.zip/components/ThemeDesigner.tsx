
import React, { useState } from 'react';
import { Palette, ChevronLeft, Save, RefreshCcw, Check, Sparkles, Loader2 } from 'lucide-react';
import { ExcaliburTheme } from '../types';

interface ThemeDesignerProps {
  onBack: () => void;
  onSave: (theme: ExcaliburTheme) => void;
  initialTheme: ExcaliburTheme;
  t: any;
}

const ThemeDesigner: React.FC<ThemeDesignerProps> = ({ onBack, onSave, initialTheme, t }) => {
  const [name, setName] = useState(t.designer.title);
  const [primary, setPrimary] = useState(initialTheme.primary);
  const [bgStart, setBgStart] = useState(initialTheme.gradient[0]);
  const [bgEnd, setBgEnd] = useState(initialTheme.gradient[1]);
  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    setIsSaving(true);
    const newTheme: ExcaliburTheme = {
      id: `custom_${Date.now()}`,
      name: name || "Untitled",
      primary,
      secondary: bgStart,
      background: bgStart,
      accent: primary,
      gradient: [bgStart, bgEnd],
      isPremium: true
    };
    setTimeout(() => {
        onSave(newTheme);
        setIsSaving(false);
        setIsSaved(true);
    }, 800);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-right duration-500 max-w-3xl mx-auto py-6 pb-20 px-4">
      <header className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-2 text-white/40 hover:text-white uppercase text-[9px] font-black tracking-widest">
          <ChevronLeft size={14} /> {t.common.back}
        </button>
        <div className="flex gap-3">
           <button onClick={() => { setPrimary("#3b82f6"); setBgStart("#000000"); setBgEnd("#111111"); }} className="p-2 bg-white/5 rounded-xl hover:bg-white/10 transition-colors"><RefreshCcw size={16} /></button>
           <button onClick={handleSave} disabled={isSaving || isSaved} className={`px-6 py-2 rounded-xl font-black text-[9px] uppercase tracking-widest shadow-lg ${isSaved ? 'bg-green-500 text-white' : 'bg-white text-black hover:scale-105'} ${isSaving ? 'opacity-50' : ''}`}>
             {isSaving ? <Loader2 size={12} className="animate-spin" /> : isSaved ? <Check size={14} /> : <Save size={14} />}
           </button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
          <div className="space-y-6 bg-black/40 backdrop-blur-2xl border border-white/5 p-6 rounded-3xl shadow-xl">
              <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-white/40">{t.designer.themeName}</label>
                  <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder={t.designer.placeholder} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-white/20 transition-all font-bold text-sm text-white" />
              </div>
              <ColorControl label={t.designer.accent} value={primary} onChange={setPrimary} />
              <ColorControl label={t.designer.bgStart} value={bgStart} onChange={setBgStart} />
              <ColorControl label={t.designer.bgEnd} value={bgEnd} onChange={setBgEnd} />
              <button onClick={handleSave} disabled={isSaving || isSaved} className="w-full py-4 bg-white text-black font-black rounded-xl text-[10px] uppercase tracking-widest shadow-lg">{t.designer.saveApply}</button>
          </div>

          <div className="relative group sticky top-4">
              <div className="w-full h-64 rounded-3xl border border-white/10 overflow-hidden relative shadow-xl" style={{ background: `linear-gradient(180deg, ${bgStart} 0%, ${bgEnd} 100%)` }}>
                 <div className="absolute inset-0 bg-white/5 backdrop-blur-xl m-4 rounded-2xl border border-white/5 p-4 flex flex-col justify-between">
                    <div className="w-12 h-1.5 rounded-full" style={{ background: primary }} />
                    <div className="flex gap-3 items-center">
                        <div className="w-10 h-10 rounded-xl shadow-lg flex items-center justify-center" style={{ background: primary }}><Sparkles size={16} className="text-white" /></div>
                        <div className="flex-1 space-y-1"><div className="w-1/2 h-2 rounded-full bg-white" /><div className="w-1/3 h-1 rounded-full bg-white/30" /></div>
                    </div>
                 </div>
              </div>
          </div>
      </div>
    </div>
  );
};

const ColorControl: React.FC<{ label: string, value: string, onChange: (v: string) => void }> = ({ label, value, onChange }) => (
    <div className="flex items-center justify-between">
        <div className="space-y-1">
            <h4 className="text-[9px] font-black text-white uppercase tracking-widest">{label}</h4>
            <p className="text-[8px] text-white/30 font-mono">{value.toUpperCase()}</p>
        </div>
        <div className="w-10 h-10 rounded-xl border border-white/10 overflow-hidden relative shadow-lg">
            <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="absolute inset-[-10px] w-[200%] h-[200%] cursor-pointer" />
        </div>
    </div>
);

export default ThemeDesigner;

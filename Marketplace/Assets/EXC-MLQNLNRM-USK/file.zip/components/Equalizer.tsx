
import React, { useState } from 'react';
import { Sliders, Crown, RotateCcw, Lock } from 'lucide-react';
import { PremiumManager } from '../services/premiumService';

const EqualizerView: React.FC<{ t: any }> = ({ t }) => {
  const isPremium = PremiumManager.isPremium();
  const bands = [
    { freq: "60Hz", label: "Bass" },
    { freq: "150Hz", label: "Low-Mid" },
    { freq: "400Hz", label: "Mid" },
    { freq: "1kHz", label: "High-Mid" },
    { freq: "2.4kHz", label: "Treble" },
    { freq: "6kHz", label: "High" },
    { freq: "15kHz", label: "Air" }
  ];

  const [values, setValues] = useState<number[]>(new Array(bands.length).fill(0));

  const presets = [
    { name: "Flat", values: [0, 0, 0, 0, 0, 0, 0] },
    { name: "Pop", values: [-2, 1, 3, 4, 3, 1, -1] },
    { name: "Rock", values: [4, 3, 1, -1, 1, 3, 4] },
    { name: "Jazz", values: [2, 1, -1, 2, 1, 3, 1] },
    { name: "Bass Boost", values: [8, 6, 2, 0, 0, 0, 0] }
  ];

  const updateBand = (idx: number, val: number) => {
    if (!isPremium) return;
    const newValues = [...values];
    newValues[idx] = val;
    setValues(newValues);
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-right duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-4xl font-black font-display text-white uppercase tracking-tight">{t.equalizer.title}</h2>
          <p className="text-white/40 text-sm">{t.equalizer.subtitle}</p>
        </div>
        <button 
          onClick={() => isPremium && setValues(new Array(bands.length).fill(0))} 
          disabled={!isPremium}
          className={`flex items-center gap-2 px-6 py-3 rounded-2xl transition-all ${isPremium ? 'bg-white/10 text-white hover:bg-white/20' : 'bg-white/2 opacity-20 text-white/20'}`}
        >
          <RotateCcw size={18} /> {t.equalizer.reset}
        </button>
      </header>

      <section className="relative group">
        {!isPremium && (
            <div className="absolute inset-0 z-20 bg-black/60 backdrop-blur-md rounded-[3rem] border border-amber-500/20 flex flex-col items-center justify-center p-8 text-center space-y-4">
                <div className="w-20 h-20 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-500 shadow-[0_0_50px_rgba(245,158,11,0.2)]">
                    <Lock size={40} />
                </div>
                <h3 className="text-2xl font-black text-white uppercase tracking-widest">{t.equalizer.locked}</h3>
                <p className="text-white/40 text-xs max-w-xs leading-relaxed">{t.equalizer.lockedDesc}</p>
                <button className="px-8 py-3 bg-amber-500 text-black font-black rounded-xl text-[9px] uppercase tracking-widest flex items-center gap-2 hover:scale-105 transition-all">
                    <Crown size={14} /> {t.common.upgradeNow}
                </button>
            </div>
        )}
        
        <div className={`bg-black/30 backdrop-blur-xl border border-white/5 rounded-[3rem] p-8 md:p-12 transition-all ${!isPremium ? 'grayscale blur-sm' : ''}`}>
          <div className="flex flex-wrap justify-center gap-6 md:gap-12">
            {bands.map((band, i) => (
              <div key={i} className="flex flex-col items-center gap-6 group">
                 <div className="relative h-64 w-12 flex items-center justify-center">
                    <div className="absolute inset-y-0 w-1.5 bg-white/5 rounded-full overflow-hidden">
                      <div className="absolute bottom-0 w-full transition-all duration-300" style={{ height: `${((values[i] + 15) / 30) * 100}%`, background: 'linear-gradient(to top, #3b82f6, #6366f1)' }} />
                    </div>
                    <input type="range" min="-15" max="15" value={values[i]} onChange={(e) => updateBand(i, parseInt(e.target.value))} disabled={!isPremium} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer orientation-vertical" style={{ writingMode: 'bt-lr', appearance: 'slider-vertical' } as any} />
                 </div>
                 <div className="text-center"><p className="text-xs font-bold text-white mb-1">{band.freq}</p><p className="text-[10px] uppercase tracking-widest text-white/30">{band.label}</p></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={!isPremium ? 'opacity-20 pointer-events-none' : ''}>
          <h3 className="text-sm font-black uppercase tracking-widest text-white/60 mb-6">{t.equalizer.presets}</h3>
          <div className="flex flex-wrap gap-4">
              {presets.map((p, i) => (
                  <button 
                    key={i} 
                    onClick={() => {
                        if (isPremium) {
                            setValues(p.values);
                        }
                    }}
                    className="px-8 py-4 bg-white/5 border border-white/5 rounded-2xl font-black text-[10px] uppercase tracking-widest text-white/40 transition-all hover:bg-white/10 hover:text-white"
                  >
                    {p.name}
                  </button>
              ))}
          </div>
      </section>
    </div>
  );
};

export default EqualizerView;

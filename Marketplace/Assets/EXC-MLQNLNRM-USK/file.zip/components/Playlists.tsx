
import React, { useState } from 'react';
import { Playlist, Song } from '../types.ts';
import { ListMusic, Plus, Play, Trash2, Music } from 'lucide-react';
import { STORAGE_KEYS } from '../constants.ts';
import { CryptoManager } from '../services/cryptoService.ts';

interface PlaylistsViewProps {
  playlists: Playlist[];
  onUpdatePlaylists: (playlists: Playlist[]) => void;
  songs: Song[];
  onPlay: (song: Song) => void;
  t: any;
}

const PlaylistsView: React.FC<PlaylistsViewProps> = ({ playlists, onUpdatePlaylists, songs, onPlay, t }) => {
  const [showCreate, setShowCreate] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState("");
  const [activePlaylist, setActivePlaylist] = useState<Playlist | null>(null);

  const createPlaylist = async () => {
    if (!newPlaylistName.trim()) return;
    const newList: Playlist = {
      id: Math.random().toString(36).substr(2, 9),
      name: newPlaylistName,
      songIds: [],
      createdAt: Date.now()
    };
    const updated = [...playlists, newList];
    onUpdatePlaylists(updated);
    setNewPlaylistName("");
    setShowCreate(false);
  };

  const deletePlaylist = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = playlists.filter(p => p.id !== id);
    onUpdatePlaylists(updated);
    if (activePlaylist?.id === id) setActivePlaylist(null);
  };

  if (activePlaylist) {
    const playlistSongs = songs.filter(s => activePlaylist.songIds.includes(s.id));
    
    return (
      <div className="space-y-8 animate-in fade-in slide-in-from-right duration-500">
        <button onClick={() => setActivePlaylist(null)} className="text-white/40 hover:text-white flex items-center gap-2 text-sm font-bold uppercase tracking-widest transition-colors">
          ← {t.playlists.back}
        </button>
        <header className="flex items-end gap-6">
           <div className="w-32 h-32 md:w-48 md:h-48 bg-gradient-to-br from-blue-600 to-indigo-900 rounded-3xl shadow-2xl flex items-center justify-center text-white/20">
              <Music size={80} />
           </div>
           <div>
              <p className="text-xs font-black uppercase tracking-[4px] text-white/40 mb-2">Playlist</p>
              <h2 className="text-4xl md:text-6xl font-black font-display mb-4">{activePlaylist.name}</h2>
              <p className="text-white/40">{playlistSongs.length} {t.playlists.stats} • {t.playlists.created} {new Date(activePlaylist.createdAt).toLocaleDateString()}</p>
           </div>
        </header>

        <div className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden backdrop-blur-md">
           {playlistSongs.length > 0 ? (
             <table className="w-full text-left">
               <thead>
                 <tr className="border-b border-white/5 text-white/30 text-[10px] font-black uppercase tracking-widest">
                   <th className="px-6 py-4 w-12">#</th>
                   <th className="px-6 py-4">{t.library.table.track}</th>
                   <th className="px-6 py-4">{t.library.table.album}</th>
                 </tr>
               </thead>
               <tbody>
                 {playlistSongs.map((song, idx) => (
                   <tr key={song.id} className="group hover:bg-white/5 cursor-pointer border-b border-white/5 last:border-0" onClick={() => onPlay(song)}>
                     <td className="px-6 py-4 text-white/30">{idx + 1}</td>
                     <td className="px-6 py-4">
                        <div className="flex items-center gap-4">
                           <img src={song.thumbnail} className="w-10 h-10 rounded-lg" />
                           <div><p className="font-bold">{song.title}</p><p className="text-xs text-white/40">{song.artist}</p></div>
                        </div>
                     </td>
                     <td className="px-6 py-4 text-sm text-white/40">{song.album}</td>
                   </tr>
                 ))}
               </tbody>
             </table>
           ) : (
             <div className="py-24 text-center text-white/20">
                <Music size={48} className="mx-auto mb-4" />
                <p>{t.playlists.empty}</p>
             </div>
           )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom duration-500">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-extrabold font-display">{t.playlists.title}</h2>
          <p className="text-white/40">{t.playlists.subtitle}</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="flex items-center gap-2 px-6 py-3 bg-white text-black font-bold rounded-2xl hover:scale-105 transition-transform">
          <Plus size={20} /> {t.playlists.new}
        </button>
      </header>

      {showCreate && (
        <div className="bg-white/5 border border-white/10 p-6 rounded-3xl flex gap-4 animate-in slide-in-from-top duration-300">
          <input type="text" placeholder="Playlist name..." className="flex-1 bg-black/40 border border-white/10 rounded-xl px-4 focus:outline-none focus:border-blue-500 transition-all font-bold text-white" value={newPlaylistName} onChange={(e) => setNewPlaylistName(e.target.value)} />
          <button onClick={createPlaylist} className="px-6 py-2 bg-blue-500 text-white font-bold rounded-xl">{t.playlists.create}</button>
          <button onClick={() => setShowCreate(false)} className="px-4 py-2 text-white/40">{t.playlists.cancel}</button>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {playlists.map(playlist => (
          <div key={playlist.id} onClick={() => setActivePlaylist(playlist)} className="group cursor-pointer space-y-4">
            <div className="aspect-square bg-gradient-to-br from-indigo-500/20 to-blue-500/20 border border-white/5 rounded-[2rem] flex items-center justify-center relative overflow-hidden transition-all duration-500 group-hover:scale-[1.02] group-hover:-translate-y-2 group-hover:border-white/20">
               <ListMusic size={60} className="text-white/10" />
               <button onClick={(e) => deletePlaylist(playlist.id, e)} className="absolute top-4 right-4 p-2 text-white/0 group-hover:text-white/40 hover:text-red-500">
                 <Trash2 size={18} />
               </button>
            </div>
            <div>
              <h4 className="font-bold text-lg">{playlist.name}</h4>
              <p className="text-sm text-white/40">{playlist.songIds.length} {t.playlists.stats}</p>
            </div>
          </div>
        ))}
        {playlists.length === 0 && !showCreate && (
          <div className="col-span-full py-32 border-2 border-dashed border-white/5 rounded-[3rem] flex flex-col items-center justify-center text-white/10">
             <ListMusic size={64} className="mb-4" />
             <p className="font-bold text-xl">{t.playlists.none}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PlaylistsView;


import React, { useState, useMemo } from 'react';
import { Search as SearchIcon, Play, Download, Check, Youtube, Loader2, SearchX, HardDriveDownload, Music2, AlertCircle, Timer } from 'lucide-react';
import { Song } from '../types.ts';
import { API_KEYS } from '../constants.ts';
import { OfflineStorage } from '../services/storageService.ts';
import { PremiumManager } from '../services/premiumService.ts';

interface SearchViewProps {
  onPlay: (s: Song) => void;
  onAddToLibrary: (s: Song) => void;
  library: Song[];
  dlHistory: number[];
  t: any;
}

const SearchView: React.FC<SearchViewProps> = ({ onPlay, onAddToLibrary, library, dlHistory, t }) => {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<any[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loadingActionId, setLoadingActionId] = useState<string | null>(null);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const remainingDl = useMemo(() => {
    const windowStart = Date.now() - (2 * 60 * 60 * 1000);
    const recentDls = dlHistory.filter(time => time > windowStart);
    return PremiumManager.getDownloadLimit() - recentDls.length;
  }, [dlHistory]);

  const normalizeTrack = (track: any) => {
    if (!track || !track.videoId) return null;
    return {
        id: track.videoId,
        title: track.title || "YouTube Track",
        artist: track.author || "Unknown Creator",
        artworkUrl: track.thumbnail || `https://i.ytimg.com/vi/${track.videoId}/hqdefault.jpg`,
        duration: track.duration || "0:00",
        url: `https://www.youtube.com/watch?v=${track.videoId}`
    };
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanQuery = query.trim();
    if (!cleanQuery) return;

    setSearching(true);
    setErrorMsg(null);
    setResults(null);
    
    try {
      const url = `https://${API_KEYS.HOSTS.PRIMARY}/search_video?query=${encodeURIComponent(cleanQuery)}&limit=12&sort_by=relevance&response_mode=default`;
      const response = await fetch(url, {
        method: 'GET',
        headers: { 
          'x-rapidapi-key': API_KEYS.RAPID_API, 
          'x-rapidapi-host': API_KEYS.HOSTS.PRIMARY 
        }
      });

      if (!response.ok) throw new Error("Search Index offline");
      
      const rawData = await response.json();
      const items = Array.isArray(rawData) ? rawData : [];
      
      const normalized = items.map(normalizeTrack).filter(t => t !== null);
      setResults(normalized);
      if (normalized.length === 0) setErrorMsg(`${t.search.resultsFor} "${cleanQuery}".`);
      
    } catch (err) {
      console.error("Search Error:", err);
      setErrorMsg(t.search.importError);
      setResults([]);
    } finally {
      setSearching(false);
    }
  };

  const fetchRealAudioData = async (track: any): Promise<Song | null> => {
    setLoadingActionId(track.id);
    try {
      const apiUrl = `https://${API_KEYS.HOSTS.DOWNLOADER}/mp3?url=${encodeURIComponent(track.url)}`;
      const response = await fetch(apiUrl, {
        headers: {
          'x-rapidapi-key': API_KEYS.RAPID_API,
          'x-rapidapi-host': API_KEYS.HOSTS.DOWNLOADER
        }
      });

      const data = await response.json();
      if (data && data.success && data.download) {
        return {
            id: `yt_${track.id}`,
            title: track.title,
            artist: track.artist,
            album: "YouTube Cloud",
            duration: 0,
            isFavorite: false,
            dateAdded: Date.now(),
            url: data.download,
            thumbnail: track.artworkUrl
        };
      }
      throw new Error("Sourcing failed");
    } catch (e: any) {
      alert(t.settings.importError);
      return null;
    } finally {
      setLoadingActionId(null);
    }
  };

  const handleDownload = async (track: any) => {
      if (remainingDl <= 0) {
          alert(t.settings.quotaError);
          return;
      }

      setDownloadingId(track.id);
      const song = await fetchRealAudioData(track);
      if (song) {
          try {
              const resp = await fetch(song.url, { mode: 'cors' });
              const blob = await resp.blob();
              await OfflineStorage.saveAudio(song.id, blob);
              onAddToLibrary({ ...song, isOffline: true });
          } catch (e) {
              alert(t.settings.importError);
          }
      }
      setDownloadingId(null);
  };

  const isAlreadySaved = (id: string) => library.some(s => s.id.includes(id));

  return (
    <div className="space-y-16 animate-in fade-in zoom-in-95 duration-1000 pt-6 pb-40">
      <section className="max-w-4xl mx-auto px-4 text-center space-y-10">
          <h2 className="text-5xl md:text-7xl font-black font-display tracking-tighter leading-none text-white">
              {t.search.findAny} <br />
              <span className="text-white/20">{t.search.sound}</span>
          </h2>

          <form onSubmit={handleSearch} className="relative group max-w-2xl mx-auto">
              <div className="absolute inset-0 bg-red-600/10 blur-[60px] opacity-0 group-focus-within:opacity-100 transition-opacity" />
              <div className="relative">
                  <SearchIcon className={`absolute left-8 top-1/2 -translate-y-1/2 transition-all duration-500 ${searching ? 'text-red-500 scale-125' : 'text-white/20'}`} size={28} />
                  <input 
                    type="text"
                    placeholder={t.search.placeholder}
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="w-full h-20 md:h-24 bg-white/5 border border-white/10 rounded-[2.5rem] pl-20 pr-10 text-xl md:text-2xl focus:outline-none focus:border-red-500/30 focus:bg-white/10 transition-all backdrop-blur-3xl font-bold text-white shadow-2xl"
                  />
              </div>
          </form>

          <div className="flex justify-center">
              <div className={`px-4 py-2 rounded-full flex items-center gap-2 text-[10px] font-black uppercase tracking-widest border transition-colors ${remainingDl <= 3 ? 'bg-red-500/10 border-red-500/20 text-red-500' : 'bg-white/5 border-white/10 text-white/40'}`}>
                  <Timer size={14} /> {remainingDl < 0 ? 0 : remainingDl} {t.settings.creditsLeft}
              </div>
          </div>
      </section>

      <section className="max-w-6xl mx-auto px-4">
          {searching ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
                  {[...Array(8)].map((_, i) => (
                      <div key={i} className="aspect-square bg-white/5 border border-white/5 rounded-[2.5rem] animate-pulse" />
                  ))}
              </div>
          ) : results && results.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {results.map((track) => (
                      <div key={track.id} className="group relative p-4 bg-white/5 border border-white/5 rounded-[2.5rem] transition-all hover:bg-white/10 flex items-center gap-5">
                          <div className="relative w-24 h-24 rounded-2xl overflow-hidden shadow-xl shrink-0 bg-black/40">
                              <img src={track.artworkUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" loading="lazy" />
                              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all">
                                  <button 
                                    onClick={async () => { 
                                        const s = await fetchRealAudioData(track); 
                                        if (s) onPlay(s); 
                                    }} 
                                    className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center shadow-2xl hover:scale-110 transition-all"
                                  >
                                      {loadingActionId === track.id ? <Loader2 size={16} className="animate-spin" /> : <Play size={20} fill="currentColor" className="ml-1" />}
                                  </button>
                              </div>
                          </div>
                          <div className="flex-1 min-w-0 pr-2">
                              <h4 className="font-black text-sm truncate mb-1 text-white">{track.title}</h4>
                              <p className="text-[10px] text-white/30 font-bold uppercase truncate">{track.artist}</p>
                              <div className="flex gap-2 mt-3">
                                  {!isAlreadySaved(track.id) ? (
                                      <button 
                                        onClick={() => handleDownload(track)}
                                        disabled={downloadingId === track.id}
                                        className={`px-3 py-1 border rounded-full text-[8px] font-black uppercase tracking-widest flex items-center gap-1 transition-all ${remainingDl <= 0 ? 'bg-red-500/10 border-red-500/10 text-red-500/40 cursor-not-allowed' : 'bg-white/5 border-white/10 text-white/40 hover:bg-white hover:text-black'}`}
                                      >
                                          {downloadingId === track.id ? <Loader2 size={10} className="animate-spin" /> : <Download size={10} />}
                                          {downloadingId === track.id ? t.search.saving : t.search.download}
                                      </button>
                                  ) : (
                                      <div className="px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-full text-[8px] font-black text-green-500 uppercase tracking-widest flex items-center gap-1">
                                          <Check size={10} /> {t.common.success}
                                      </div>
                                  )}
                              </div>
                          </div>
                      </div>
                  ))}
              </div>
          ) : !searching && errorMsg ? (
              <div className="flex flex-col items-center justify-center text-white/20 py-20 gap-4">
                  <SearchX size={64} />
                  <p className="font-bold text-xl">{errorMsg}</p>
              </div>
          ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 py-10">
                  <FeatureDetail icon={<Youtube className="text-red-500" />} title={t.search.features.yt} desc={t.search.features.ytDesc} />
                  <FeatureDetail icon={<Music2 className="text-green-500" />} title={t.search.features.sp} desc={t.search.features.spDesc} />
                  <FeatureDetail icon={<HardDriveDownload className="text-amber-500" />} title={t.search.features.off} desc={t.search.features.offDesc} />
              </div>
          )}
      </section>
    </div>
  );
};

const FeatureDetail = ({ icon, title, desc }: any) => (
    <div className="p-8 bg-black/20 border border-white/5 rounded-[2.5rem] text-center space-y-4 backdrop-blur-3xl">
        <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mx-auto">{icon}</div>
        <h4 className="font-black text-sm uppercase tracking-tight text-white">{title}</h4>
        <p className="text-[10px] text-white/20 leading-relaxed font-medium">{desc}</p>
    </div>
);

export default SearchView;

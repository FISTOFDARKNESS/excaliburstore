
import React, { useRef, useState, useMemo } from 'react';
import { ExcaliburTheme, Language } from '../types';
import { THEMES } from '../constants';
import { Check, Crown, Globe, Database, Download, Upload, Palette, Sliders, Sparkles, FolderOpen, Timer, ChevronRight, X } from 'lucide-react';
import { PremiumManager } from '../services/premiumService';
import EqualizerView from './Equalizer.tsx';

interface SettingsViewProps {
  currentTheme: ExcaliburTheme;
  customThemes?: ExcaliburTheme[];
  onUpdateTheme: (t: ExcaliburTheme) => void;
  onOpenDesigner: () => void;
  currentLang: Language;
  onUpdateLang: (l: Language) => void;
  onExport: () => void;
  onImport: (file: File) => void;
  dlHistory: number[];
  t: any;
}

const SettingsView: React.FC<SettingsViewProps> = ({ 
  currentTheme, customThemes = [], onUpdateTheme, onOpenDesigner, currentLang, onUpdateLang, onExport, onImport, dlHistory, t 
}) => {
  const isPremium = PremiumManager.isPremium();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showStudio, setShowStudio] = useState(false);

  const remainingDl = useMemo(() => {
    const windowStart = Date.now() - (2 * 60 * 60 * 1000);
    const recentDls = dlHistory.filter(time => time > windowStart);
    const limit = PremiumManager.getDownloadLimit();
    const remaining = limit - recentDls.length;
    return { remaining: remaining < 0 ? 0 : remaining, limit };
  }, [dlHistory]);

  const languages: { code: Language; name: string; flag: string }[] = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'pt', name: 'Português', flag: '🇧🇷' },
    { code: 'it', name: 'Italiano', flag: '🇮🇹' },
  ];

  const allThemes = [...THEMES, ...customThemes];

  if (showStudio) {
      return (
          <div className="space-y-6 animate-in slide-in-from-right duration-500">
              <button 
                onClick={() => setShowStudio(false)} 
                className="flex items-center gap-2 text-white/40 hover:text-white uppercase text-[10px] font-black tracking-widest mb-6"
              >
                  <X size={14} /> {t.common.close} {t.nav.studio}
              </button>
              <EqualizerView t={t} />
          </div>
      );
  }

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom duration-500 pb-20">
      <header className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 border border-white/20 rounded-full text-[9px] font-black tracking-widest text-white uppercase">
              <Sliders size={12} /> {t.nav.settings}
          </div>
          <h2 className="text-4xl font-black font-display uppercase tracking-tight">{t.settings.title}</h2>
          <p className="text-white/40 text-sm">{t.settings.subtitle}</p>
      </header>

      {/* QUICK STUDIO ACCESS */}
      <section 
        onClick={() => setShowStudio(true)}
        className="group bg-gradient-to-br from-blue-600/20 to-indigo-900/20 border border-blue-500/20 rounded-3xl p-8 cursor-pointer hover:from-blue-600/30 hover:to-indigo-900/30 transition-all shadow-xl"
      >
          <div className="flex items-center justify-between">
              <div className="flex items-center gap-5">
                  <div className="w-12 h-12 rounded-2xl bg-blue-500 flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
                      <Sliders size={24} />
                  </div>
                  <div>
                      <h3 className="text-xl font-black uppercase tracking-tight">{t.settings.audioStudio}</h3>
                      <p className="text-[10px] text-white/40 font-bold uppercase tracking-widest">{t.settings.studioDesc}</p>
                  </div>
              </div>
              <ChevronRight size={24} className="text-white/20 group-hover:text-white transition-colors" />
          </div>
      </section>

      <section className="bg-white/5 border border-white/5 rounded-3xl p-8 space-y-6">
          <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500 border border-amber-500/20">
                  <Timer size={20} />
              </div>
              <div className="flex-1">
                  <h3 className="text-lg font-black uppercase tracking-tight">{t.settings.quota}</h3>
                  <p className="text-[10px] text-white/30 font-bold uppercase tracking-wider">{t.settings.quotaInfo.replace('{limit}', remainingDl.limit.toString())}</p>
              </div>
              <div className="text-right">
                  <p className="text-2xl font-black text-white">{remainingDl.remaining}</p>
                  <p className="text-[8px] text-white/40 font-black uppercase">{t.settings.creditsLeft}</p>
              </div>
          </div>
      </section>

      <section className="space-y-6">
          <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                  <Palette size={20} className="text-purple-400" />
                  <h3 className="text-sm font-black uppercase tracking-widest">{t.settings.theme}</h3>
              </div>
              {isPremium && (
                  <button onClick={onOpenDesigner} className="px-4 py-2 bg-white text-black font-black rounded-xl text-[9px] uppercase tracking-widest flex items-center gap-2 hover:scale-105 transition-all">
                      <Sparkles size={12} /> {t.settings.designer}
                  </button>
              )}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {allThemes.map(theme => (
                  <button 
                    key={theme.id}
                    onClick={() => onUpdateTheme(theme)}
                    disabled={theme.isPremium && !isPremium}
                    className={`relative p-4 rounded-2xl border transition-all flex flex-col gap-3 ${
                        currentTheme.id === theme.id 
                        ? 'bg-white text-black border-white shadow-lg' 
                        : 'bg-black/20 border-white/5 text-white/60 hover:border-white/20'
                    } ${theme.isPremium && !isPremium ? 'opacity-30' : ''}`}
                  >
                     <div className="flex justify-between items-center w-full">
                         <h4 className="font-bold text-[10px] uppercase truncate">{theme.name}</h4>
                         {theme.isPremium && <Crown size={10} className="text-amber-500" />}
                     </div>
                     <div className="flex -space-x-2">
                         <div className="w-6 h-6 rounded-full border border-black/10" style={{ background: theme.primary }} />
                         <div className="w-6 h-6 rounded-full border border-black/10" style={{ background: theme.gradient[1] }} />
                     </div>
                  </button>
              ))}
          </div>
      </section>

      <section className="space-y-6">
          <div className="flex items-center gap-3">
              <Globe size={20} className="text-blue-400" />
              <h3 className="text-sm font-black uppercase tracking-widest">{t.settings.lang}</h3>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {languages.map(lang => (
                  <button 
                    key={lang.code}
                    onClick={() => onUpdateLang(lang.code)}
                    className={`p-4 rounded-2xl border transition-all flex items-center gap-4 ${
                        currentLang === lang.code 
                        ? 'bg-white text-black border-white shadow-lg' 
                        : 'bg-black/20 border-white/5 text-white/60 hover:border-white/20'
                    }`}
                  >
                     <span className="text-2xl">{lang.flag}</span>
                     <span className="font-bold uppercase text-[10px] tracking-widest">{lang.name}</span>
                  </button>
              ))}
          </div>
      </section>

      <section className="bg-white/5 border border-white/5 rounded-3xl p-8 space-y-8">
          <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-400 border border-blue-500/20">
                  <FolderOpen size={20} />
              </div>
              <h3 className="text-xl font-black uppercase tracking-tight">{t.library.title}</h3>
          </div>
          <div className="grid grid-cols-2 gap-4">
              <button onClick={onExport} className="py-4 bg-white text-black font-black rounded-2xl flex items-center justify-center gap-3 transition-all uppercase tracking-widest text-[9px]">
                  <Download size={16} /> {t.settings.export}
              </button>
              <button onClick={() => fileInputRef.current?.click()} className="py-4 bg-white/5 border border-white/10 text-white font-black rounded-2xl flex items-center justify-center gap-3 transition-all uppercase tracking-widest text-[9px]">
                  <Upload size={16} /> {t.settings.import}
              </button>
              <input type="file" ref={fileInputRef} className="hidden" accept=".exc" onChange={(e) => e.target.files?.[0] && onImport(e.target.files[0])} />
          </div>
      </section>
    </div>
  );
};

export default SettingsView;

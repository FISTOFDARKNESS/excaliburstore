
import React, { useState, useEffect } from 'react';
import { Crown, Zap, Globe, Layers, Infinity, ShieldCheck, CreditCard, Shield, X, ArrowRight, Sparkles, Star, Flame, ShieldAlert, Loader2, CheckCircle, AlertTriangle } from 'lucide-react';
import { PremiumPlan } from '../types.ts';
import { PRICES } from '../constants.ts';

declare global {
  interface Window {
    paypal?: any;
  }
}

const PremiumView: React.FC<{ onActivate: (plan: PremiumPlan) => void, t: any }> = ({ onActivate, t }) => {
  const [selectedPlan, setSelectedPlan] = useState<PremiumPlan>(PremiumPlan.YEARLY);
  const [showCheckout, setShowCheckout] = useState(false);
  const [isSdkLoaded, setIsSdkLoaded] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Carrega o SDK do PayPal dinamicamente
  useEffect(() => {
    if (showCheckout && !window.paypal) {
      const script = document.createElement('script');
      // Usando o Client ID de Sandbox para o protótipo. 
      // Para produção, substitua 'sb' pelo seu Client ID real do PayPal Developer Portal.
      script.src = `https://www.paypal.com/sdk/js?client-id=sb&currency=USD&intent=capture`;
      script.async = true;
      script.onload = () => setIsSdkLoaded(true);
      document.body.appendChild(script);
    } else if (window.paypal) {
      setIsSdkLoaded(true);
    }
  }, [showCheckout]);

  // Renderiza os botões do PayPal quando o SDK estiver pronto
  useEffect(() => {
    if (isSdkLoaded && showCheckout && window.paypal) {
      const container = document.getElementById('paypal-button-container');
      if (container) {
        container.innerHTML = ''; // Limpa para evitar duplicatas
        window.paypal.Buttons({
          style: {
            layout: 'vertical',
            color: 'gold',
            shape: 'pill',
            label: 'paypal',
            height: 50
          },
          createOrder: (data: any, actions: any) => {
            return actions.order.create({
              purchase_units: [{
                description: `Excalibur Prestige - ${selectedPlan}`,
                amount: {
                  currency_code: 'USD',
                  value: PRICES[selectedPlan]
                }
              }]
            });
          },
          onApprove: async (data: any, actions: any) => {
            const order = await actions.order.capture();
            console.log("Pagamento aprovado:", order);
            setIsSuccess(true);
            setTimeout(() => {
              onActivate(selectedPlan);
            }, 3000);
          },
          onError: (err: any) => {
            console.error("Erro no PayPal:", err);
            setError("Ocorreu um erro no processamento do pagamento. Tente novamente.");
          }
        }).render('#paypal-button-container');
      }
    }
  }, [isSdkLoaded, showCheckout, selectedPlan]);

  return (
    <div className="min-h-screen space-y-12 animate-in fade-in slide-in-from-bottom duration-700 pt-6 pb-40">
      <header className="text-center space-y-4 max-w-2xl mx-auto px-6">
         <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/10 border border-amber-500/20 rounded-full text-amber-500 text-[9px] font-black uppercase tracking-widest">
            <Star size={12} className="fill-amber-500" /> {t.premium.fidelity}
         </div>
         <h2 className="text-3xl md:text-5xl font-black font-display uppercase tracking-tight leading-tight text-white">
            {t.premium.title}
         </h2>
         <p className="text-white/40 text-xs md:text-sm leading-relaxed">{t.premium.subtitle}</p>
      </header>

      {!isSuccess ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 px-6 max-w-5xl mx-auto">
            <PlanCard title={t.premium.essential} subtitle={t.premium.monthly} price={PRICES[PremiumPlan.MONTHLY]} selected={selectedPlan === PremiumPlan.MONTHLY} onSelect={() => setSelectedPlan(PremiumPlan.MONTHLY)} icon={<Zap />} />
            <PlanCard title={t.premium.pro} subtitle={t.premium.yearly} price={PRICES[PremiumPlan.YEARLY]} selected={selectedPlan === PremiumPlan.YEARLY} onSelect={() => setSelectedPlan(PremiumPlan.YEARLY)} icon={<Flame />} badge={t.premium.save} />
            <PlanCard title={t.premium.legendary} subtitle={t.premium.lifetime} price={PRICES[PremiumPlan.LIFETIME]} selected={selectedPlan === PremiumPlan.LIFETIME} onSelect={() => setSelectedPlan(PremiumPlan.LIFETIME)} icon={<Crown />} badge={t.premium.best} />
          </div>

          <div className="max-w-5xl mx-auto px-6">
            <div className="bg-black/40 backdrop-blur-2xl border border-white/5 rounded-3xl p-8 md:p-12 overflow-hidden">
                {!showCheckout ? (
                    <div className="space-y-12">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                            <Benefit icon={<ShieldCheck size={20} />} title={t.premium.benefits.security} desc={t.premium.benefits.securityDesc} />
                            <Benefit icon={<Layers size={20} />} title={t.premium.benefits.theme} desc={t.premium.benefits.themeDesc} />
                            <Benefit icon={<Infinity size={20} />} title={t.premium.benefits.indexing} desc={t.premium.benefits.indexingDesc} />
                            <Benefit icon={<Sparkles size={20} />} title={t.premium.benefits.ai} desc={t.premium.benefits.aiDesc} />
                            <Benefit icon={<Globe size={20} />} title={t.premium.benefits.streaming} desc={t.premium.benefits.streamingDesc} />
                            <Benefit icon={<CreditCard size={20} />} title={t.premium.benefits.studio} desc={t.premium.benefits.studioDesc} />
                        </div>
                        <div className="flex flex-col items-center">
                            <button onClick={() => setShowCheckout(true)} className="w-full sm:w-auto px-10 py-4 bg-white text-black font-black rounded-2xl hover:scale-105 transition-all uppercase tracking-widest flex items-center justify-center gap-3 text-[10px] shadow-lg">
                                {t.premium.activate} <ArrowRight size={16} />
                            </button>
                        </div>
                    </div>
                ) : (
                    <div className="max-w-xl mx-auto animate-in zoom-in-95 duration-300">
                        <div className="flex items-center justify-between mb-8 text-white">
                            <div className="flex items-center gap-3">
                                <Shield size={20} className="text-blue-400" />
                                <h3 className="font-black uppercase tracking-widest text-[10px]">{t.premium.checkout.title}</h3>
                            </div>
                            <button onClick={() => setShowCheckout(false)} className="p-2 text-white/20 hover:text-white transition-colors"><X size={20} /></button>
                        </div>
                        <div className="space-y-6 text-white">
                            <div className="p-5 bg-white/5 rounded-2xl border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                <div><p className="text-[8px] text-white/40 font-black uppercase">{t.premium.checkout.plan}</p><p className="text-lg font-black uppercase">{selectedPlan}</p></div>
                                <div className="sm:text-right"><p className="text-[8px] text-white/40 font-black uppercase">{t.premium.checkout.price}</p><p className="text-2xl font-black text-amber-500">${PRICES[selectedPlan]}</p></div>
                            </div>
                            
                            <div className="p-8 sm:p-10 bg-white/[0.02] border border-white/10 rounded-[2.5rem] text-center space-y-8 relative overflow-hidden min-h-[400px]">
                                <div className="space-y-4">
                                    <div className="space-y-2">
                                        <h4 className="font-black uppercase tracking-tight text-lg">{t.premium.checkout.payWithPaypal}</h4>
                                        <p className="text-[10px] text-white/50 px-4 sm:px-8 leading-relaxed italic">{t.premium.checkout.paypalDesc}</p>
                                    </div>
                                </div>

                                {error && (
                                    <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3 text-red-500 text-[9px] font-black uppercase tracking-widest">
                                        <AlertTriangle size={16} /> {error}
                                    </div>
                                )}

                                <div className="relative z-10">
                                    {!isSdkLoaded ? (
                                        <div className="flex flex-col items-center justify-center py-10 space-y-4">
                                            <Loader2 className="animate-spin text-amber-500" size={32} />
                                            <p className="text-[8px] text-white/20 font-black uppercase tracking-widest">{t.premium.checkout.communicating}</p>
                                        </div>
                                    ) : (
                                        <div id="paypal-button-container" className="w-full animate-in fade-in duration-500"></div>
                                    )}
                                </div>
                                
                                <p className="text-[8px] text-white/20 font-medium uppercase tracking-widest">{t.premium.checkout.enc}</p>
                            </div>
                        </div>
                    </div>
                )}
            </div>
          </div>
        </>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 animate-in zoom-in-95 duration-700 px-6 text-center">
             <div className="w-24 h-24 rounded-full bg-green-500 flex items-center justify-center text-white mb-8 shadow-[0_0_50px_rgba(34,197,94,0.4)]">
                <CheckCircle size={48} />
             </div>
             <h3 className="text-3xl font-black uppercase tracking-tighter mb-4 text-white">{t.premium.checkout.confirmed}</h3>
             <p className="text-white/40 font-bold uppercase tracking-widest text-[10px]">{t.premium.checkout.successDesc}</p>
             <p className="mt-2 text-blue-400 font-black text-[8px] uppercase tracking-widest animate-pulse">{t.premium.checkout.redirecting}</p>
        </div>
      )}
    </div>
  );
};

const PlanCard: React.FC<{ title: string, subtitle: string, price: string, selected: boolean, onSelect: () => void, icon: React.ReactNode, badge?: string }> = ({ title, subtitle, price, selected, onSelect, icon, badge }) => (
    <div onClick={onSelect} className={`relative p-8 rounded-[2.5rem] border transition-all cursor-pointer flex flex-col h-full ${selected ? 'bg-white text-black border-white scale-105 shadow-xl z-10' : 'bg-white/5 border-white/5 text-white hover:bg-white/10'}`}>
        {badge && <div className={`absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest whitespace-nowrap ${selected ? 'bg-black text-white' : 'bg-amber-500 text-black'}`}>{badge}</div>}
        <div className={`mb-4 w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${selected ? 'bg-black/5 text-black' : 'bg-white/5 text-white'}`}>{React.cloneElement(icon as any, { size: 20 })}</div>
        <div className="mb-6 flex-1"><h3 className="text-[9px] font-black uppercase opacity-40">{title}</h3><p className="text-base font-black truncate">{subtitle}</p></div>
        <div className="flex items-baseline gap-1 mt-auto"><span className="text-xl font-black">$</span><span className="text-4xl font-black">{price}</span></div>
    </div>
);

const Benefit: React.FC<{ icon: React.ReactNode, title: string, desc: string }> = ({ icon, title, desc }) => (
    <div className="flex gap-4">
        <div className="text-amber-500 w-10 h-10 rounded-xl bg-amber-500/5 border border-amber-500/10 flex items-center justify-center shrink-0">{icon}</div>
        <div className="space-y-1 text-white"><h4 className="font-bold text-xs uppercase">{title}</h4><p className="text-[10px] text-white/30 leading-relaxed">{desc}</p></div>
    </div>
);

export default PremiumView;
